from typing import List
from numpy import ndarray

def obtener_seleccion(mensaje : str, max : int) -> int:
    """Realiza una pregunta al usuario y retorna su respuesta.

    Args:
        mensaje (str): pregunta por realizar
        max (int): maximo valor valido

    Returns:
        int: respuesta del usuario
    """
    respuesta = None
    error = f"Debe ingresar un numero de 1 al {max}."
    while respuesta == None:
        try:
            print(mensaje)
            respuesta = int(input())
            if respuesta <= 0 or respuesta > max:
                print(error)
                respuesta = None
        except:
            print(error)
            respuesta = None
    return respuesta

def obtener_tipo_departamento() -> int:
    """Obtiene una letra de la A a la D que representa el tipo de departamento que el usuario
    comprara. La convierte en un numero del 0 al 3.
    """
    tipo = ""
    while tipo == "":
        tipo = input("Por favor escoja el tipo de departamento que desea comprar: ").strip().upper()
        if tipo in "ABCD" and len(tipo) == 1:
            return ord(tipo) - 65
        else:
            print("Debe ingresar un tipo entre A y D.")
            tipo = ""

def dig_verificador(run: int) -> str:
    """Encuentra el digito verificador de un run dado.
    """
    # Algoritmo modulo 11 para encontrar digito verificador de un run...
    sum = 0
    i = 2
    while run > 0:
        if (i == 8):
            i = 2
        sum += run % 10 * i
        run //= 10
        i += 1
    dig = str(11 - sum%11)
    if dig == "10":
        dig = "k"
    elif dig == "11":
        dig = "0"
    return dig

def obtener_run():
    """Obtiene un run valido del usuario y asigna su valor sin dig. verificador.
    a la variable global run.
    Si el usuario se "rinde" y no entrega su run, asigna None a run.
    """
    global run
    run = -1
    while run == -1:
        # run_raw contiene el valor ingresado por el usuario sin procesar.
        run_raw = input("Por favor ingrese su RUN: ")
        
        # run podria estar en uno siguientes formatos:
        # 12.345.678-9
        # 12345678-9
        # Tambien puede contener espacios o saltos de linea.
        
        # Aqui quitamos posibles caracteres innecesarios.
        run_raw = run_raw.strip().replace(" ", "").replace(".", "")
        
        # Aqui verificamos que el run sea valido.
        if run_raw == "" or run_raw.count("-") > 1:
            print("Debe ingresar un run valido.")
        elif "-" not in run_raw:
            print("Debe ingresar su run con guion")
        else:
            try:
                run_raw = run_raw.split("-")
                run = int(run_raw[0])
                if run <= 0:
                    run = -1
                    print("Debe ingresar un run valido. (positivo)")
                else:
                    dig = run_raw[1]
                    if dig.lower() != dig_verificador(run):
                        print("El digito verificador no coincide con el rut entregado.")
                        run = -1
            except:
                print("Debe ingresar un run valido")
        if run == -1:
            mensaje =  "Desea intentarlo nuevamente?\n1- Si\n2- No"
            reintentar = obtener_seleccion(mensaje, 2)
            if reintentar == 2:
                run = None

def comprar_departamento():
    global deptos, run, compradores, ventas
    while True:
        mensaje = "Por favor escoja el piso en el que desea comprar su departamento: "
        mostrar_departamentos()
        piso = obtener_seleccion(mensaje, 10) - 1
        mostrar_departamentos()
        tipo = obtener_tipo_departamento()
        if not deptos[piso][tipo]:
            print("Lo sentimos, el departamento seleccionado no se encuentra disponible.")
            mensaje = "Desea escojer otro departamento?\n1- Si\n2- No"
            cont = obtener_seleccion(mensaje, 2)
            if cont == 2:
                return
            else:
                continue
        obtener_run()
        if run == None:
            return
        else:
            mensaje = f"Run: {run}\nDepto: {chr(tipo + 65)}-{piso+1}\nSon los datos correctos?\n1-Si\n2-No"
            corr = obtener_seleccion(mensaje, 2)
            if corr == 1:
                ha_comprado = False
                for c in compradores:
                    if c[0] == run:
                        ha_comprado = True
                        c[1] += 1
                        break
                if not ha_comprado:
                    compradores.append([run, 1])
                deptos[piso][tipo] = False
                ventas[tipo] += 1
                print("Su compra ha sido realizada!")
                return
            elif corr == 2:
                mensaje = f"Debera ingresar sus datos nuevamente. Aun desea realizar la compra?\n1- Si\n2- No"
                cont = obtener_seleccion(mensaje, 2)
                if mensaje == 2:
                    return

def mostrar_departamentos():
    """Muestra el estado actual del edificio, marcando con X los departamentos vendidos.
    """
    global deptos
    # Podriamos definir el encabezado en una sola linea pero de esta manera es mas legible 
    # para nosotros.
    encabezado =  "PISO|  TIPO |\n"
    encabezado += "    |A|B|C|D|\n"
    
    # El edificio consiste en una serie de lineas del 10 al 1, indicando el numero de linea y
    # el estado de los departamentos.
    edificio = ""
    for p in range(10):
        # Debe mantenerse la alineacion de la tabla tanto cuando el numero de piso tiene una 
        # cifra como cuando tiene 2:
        fila = f"   {p + 1}|" if p < 9 else f"  {p + 1}|"
        
        # Se agregan los departamentos segun si estan o no vendidos.
        for d in range(4):
            fila += " |" if deptos[p][d] else "X|"
        edificio = fila + "\n" + edificio
    print(encabezado + edificio)

def ver_listado_compradores():
    global compradores
    print("Mostrando listado de compradores: ")
    for c in compradores:
        plural = "s" if c[1] > 1 else ""
        print(f"{c[0]}-{dig_verificador(c[0])} - {c[1]} compra{plural}.")

def mostrar_ganancias_totales():
    global ventas
    global precios
    mensaje = "Listado de ventas:\n"
    total = 0
    for i in range(4):
        subtot = precios[i] * ventas[i]
        mensaje += f"{chr(65 + i)} ({precios[i]} UF) x {ventas[i]} = {subtot}\n"
        total += subtot
    mensaje += f"Total: {total}"
    print(mensaje)

def salir():
    print("Gracias por usar Casa Feliz. \nSientase como en casa!")
    print("Nombre: Angel Gabriel Ishk Rojas Navia")
    print("Rut: 19.837.745-7")
    print("10 - Julio - 2023")
    input("Presione ENTER para finalizar.")
    exit()

# Doble lista de booleanos. Cada elemento representa un departamento. True = Disponible
# La primera coordenada es el piso y la segunda el departamento, ordenados de 1 a 10 y de A a D
run = -1
# Lista de Listas de largo 2 [rut, nro compras]
compradores = []
# Lista de booleans que representan cada departamento. True significa disponible y False vendido.
deptos = ndarray(shape=(10, 4), dtype=bool)
deptos.fill(True)
# Lista de precios para cada tipo de departamento.
precios = [3800, 3000, 2800, 2500]
# lista de cantidades vendidas por cada tipo. Largo 4, un espacio para cada tipo de depto.
# Aunque es redundante, puesto que se puede calcular de "deptos", resulta mas manejable tener
# esta lista secundaria para acceder directamente a la cantidad de ventas realizadas.
ventas = [0]*4 

def main():
    """Funcion principal.
    """
    # Mensaje principal para preguntar al usuario lo que desea hacer.
    mensaje =  "Seleccione una de las siguientes opciones: \n"
    mensaje += "1- Comprar departamento.\n"
    mensaje += "2- Mostrar departamentos disponibles.\n"
    mensaje += "3- Ver listado de compradores.\n"
    mensaje += "4- Mostrar ganancias totales.\n"
    mensaje += "5- Salir.\n"
    sel = -1
    while sel != 5:
        sel = obtener_seleccion(mensaje, 5)
        if sel == 1:
            comprar_departamento()
        if sel == 2:
            mostrar_departamentos()
        if sel == 3:
            ver_listado_compradores()
        if sel == 4:
            mostrar_ganancias_totales()
        if sel == 5:
            salir()

main()